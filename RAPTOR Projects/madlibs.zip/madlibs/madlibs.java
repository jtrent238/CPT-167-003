/**
  * NAME:
  * DATE:
  * FILE:
  * COMMENTS:
  */

public class madlibs extends eecs.Gui
{
   public static void main(String[] args)
   {
      // declare variables
      String raptor_prompt_variable_zzyz = null;
      ?? noun1 = ??;
      ?? adjective1 = ??;
      ?? noun2 = ??;
      ?? verb1 = ??;
      
      raptor_prompt_variable_zzyz = "Enter a type of animal:  ";
      noun1 = get???(raptor_prompt_variable_zzyz);
      raptor_prompt_variable_zzyz = "Enter a singular noun associated with the animal: ";
      noun2 = get???(raptor_prompt_variable_zzyz);
      raptor_prompt_variable_zzyz = "Enter an adjective: ";
      adjective1 = get???(raptor_prompt_variable_zzyz);
      raptor_prompt_variable_zzyz = "Enter a past tense verb: ";
      verb1 = get???(raptor_prompt_variable_zzyz);
      print("Mary had a little " + noun1 + " Its " + noun2 + " was as " + adjective1 + " as snow. " + " And every where that Mary " + verb1 + " the " + noun1 + " was sure to go.");
   } // close main
} // close madlibs
