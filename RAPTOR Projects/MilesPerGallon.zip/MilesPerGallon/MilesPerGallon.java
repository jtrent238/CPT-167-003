/**
  * NAME:
  * DATE:
  * FILE:
  * COMMENTS:
  */

public class MilesPerGallon extends eecs.Gui
{
   public static void main(String[] args)
   {
      // declare variables
      String raptor_prompt_variable_zzyz = null;
      ?? gallons = ??;
      ?? miles = ??;
      ?? mpg = ??;
      
      raptor_prompt_variable_zzyz = "Distance in miles: ";
      miles = get???(raptor_prompt_variable_zzyz);
      raptor_prompt_variable_zzyz = "Fuel used in gallons: ";
      gallons = get???(raptor_prompt_variable_zzyz);
      mpg = miles / gallons;
      printLine("Your Miles Per Gallon (mpg) is: " + mpg);
   } // close main
} // close MilesPerGallon
