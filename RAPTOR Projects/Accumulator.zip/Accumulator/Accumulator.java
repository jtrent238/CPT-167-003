/**
  * NAME:
  * DATE:
  * FILE:
  * COMMENTS:
  */

public class Accumulator extends eecs.Gui
{
   public static void main(String[] args)
   {
      // declare variables
      String raptor_prompt_variable_zzyz = null;
      ?? total = ??;
      ?? i = ??;
      ?? stamps = ??;
      
      openReadFile("Stamps.txt");
      i = 0;
      total = 0;
      raptor_prompt_variable_zzyz = "Stamps Collected";
      stamps = read???();
raptor_prompt_variable_zzyz      while	(1)
      {
         i = i + 1;
         total = total + stamps;
         if (i >= 30)	break;
      }
      printLine("You collected " + total + " this month.");
   } // close main
} // close Accumulator
