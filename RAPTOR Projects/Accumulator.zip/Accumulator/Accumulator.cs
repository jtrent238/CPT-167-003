using System;
using System.IO;
using System.Text;

namespace Accumulator
{
   public class main_class
   {
      static System.Random random_generator = new System.Random();
      public static void Main(string[] args)
      {
         string raptor_prompt_variable_zzyz;
         ?? total;
         ?? i;
         ?? stamps;
      
         redirect_input("Stamps.txt");
         i =0;
         total =0;
         raptor_prompt_variable_zzyz ="Stamps Collected";
         Console.WriteLine(raptor_prompt_variable_zzyz);
         stamps= Double.Parse(Console.ReadLine());
         while (1)
         {
            i =i+1;
            total =total+stamps;
            if (i>=30)) break;
         }
         Console.WriteLine("You collected "+total+" this month.");
      }
   }
}
