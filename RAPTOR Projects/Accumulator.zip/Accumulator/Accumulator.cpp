#include <iostream>
#include <string>

using namespace std;
int main()
{
   string raptor_prompt_variable_zzyz;
   ?? total;
   ?? i;
   ?? stamps;

   redirect_input("Stamps.txt");
   i =0;
   total =0;
   raptor_prompt_variable_zzyz ="Stamps Collected";
   cout << raptor_prompt_variable_zzyz << endl;
   cin >> stamps;
   while (1)
   {
      i =i+1;
      total =total+stamps;
      if (i>=30)) break;
   }
   cout << "You collected "+total+" this month." << endl;
   return 0;
}
